#ifndef DIRDATA_H
#define DIRDATA_H

const int nFIELD_WIDTH = 50;
const int nLINE_WIDTH = 153;

struct DirData
{
	CString szInput;
	CString szArchive;
	CString szError;
};

#endif